<?php
// Maestro's style!
// Welcome to main library, it's your place to enter all options
// To get all thing done, just:
// include everywhere $mainlibrary = $_SERVER["DOCUMENT_ROOT"] . "/lib/main.php";

// ROOTs
$imgroot =  $_SERVER["DOCUMENT_ROOT"] . "/img/";

$staticroot =  $_SERVER["DOCUMENT_ROOT"] . "/static/";

$libroot =  $_SERVER["DOCUMENT_ROOT"] . "/lib/";

$funcroot =  $_SERVER["DOCUMENT_ROOT"] . "/func/";

$temproot =  $_SERVER["DOCUMENT_ROOT"] . "/templates/";

// DB connection info
$db_server = "xxxxx";
$db_user = "xxxxx";
$db_pass = "xxxxx";

$db_main = "xxxxx";


// url
$url = "";

//meta
$title = "";
$keywords = "";
$desc = "";

$favicon = $url . "img/favicon.png";

?>
