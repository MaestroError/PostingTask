
<footer class="page-footer mt-4 font-small blue">

  <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <a href="https://maestroerror.ge/"> MaestroError.ge</a>
  </div>

</footer>

<script type="text/javascript">
  $(document).ready(function(){

  });
</script>

</body>
</html>
