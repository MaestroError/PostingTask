Hello World!

Here you can see some info about structure of app:

 DB - Folder for database files for your migrations (MySQL)

 func - all functions which used to get things done!

 static - folder for all your static files, such as CSS, JS and etc.

 lib - folder for library, where we save all cross file info

 You need to open lib/main.php and enter your options, such as DB account setting, site URL and etc.
