<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 4.9.0.1
 */

/**
 * Database `a0226780_neg`
 */

/* `a0226780_neg`.`posts` */
$posts = array(
  array('pk' => '7','heading' => 'Test1','post_text' => 'testing for posts','author' => 'maestro (1)')
);

/* `a0226780_neg`.`user` */
$user = array(
  array('pk' => '1','username' => 'maestro','password' => '$2y$10$dziq0f00CFkGvtV6SwGoquisTaoHA6c/YueGaZNIdWpvNQs8aYU3u','mail' => 'revaz.gh@gmail.com','user_desc' => NULL,'img' => 'default.png','status' => 'notactive','reg_date' => '2020-01-21 12:06:30')
);
